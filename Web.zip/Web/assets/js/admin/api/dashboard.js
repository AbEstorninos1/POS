let salesChart = null;
let topProductsChart = null;

async function loadDashboard() {
  try {
    const res = await fetch('../api/admin/sales/dashboard.php', { cache: 'no-store' });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const data = await res.json();

    if (!data.success) {
      throw new Error('Failed to load dashboard');
    }

    document.getElementById('statSales').textContent =
      '₱' + Number(data.stats.sales).toLocaleString('en-PH', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });

    document.getElementById('statTransactions').textContent =
      data.stats.transactions;

    document.getElementById('statProducts').textContent =
      data.stats.products;

    document.getElementById('statLowStock').textContent =
      data.stats.lowStock;

    renderLowStock(data.lowStockProducts);
    renderRecentTransactions(data.recentTransactions);

    try {
      renderCharts(data);
    } catch (chartError) {
      console.error('Chart Error:', chartError);
    }

  } catch (error) {
    console.error('Dashboard Error:', error);
  }
}

loadDashboard();