// Sa mga product muna hinahanap, tapos sa variants nila. Kapag variant yung nag-match, kasama yung variant sa return
function findByBarcode(code) {
  for (const product of products) {
    if (product.barcode === code) {
      return { product: product, variant: null };
    }

    for (const variant of product.variants) {
      if (variant.barcode === code) {
        return { product: product, variant: variant };
      }
    }
  }

  return null;
}

async function handleBarcode(code) {
  const found = findByBarcode(code.trim());

  if (found === null) {
    scannerStatus.textContent = 'Product not found: ' + code;
    return;
  }

  // inooff muna yung camera pagka-nakita na yung product
  await stopScanner();

  selectProduct(found.product.categoryName, found.product, found.variant);
  //Default lang na value pag iniscan is 1
  numInput.value = '1';
  pressEnter();
}
