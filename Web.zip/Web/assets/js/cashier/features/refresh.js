  function confirmLogout() {
    showModal('Logout?', () => {
      location.href = '../auth/logout.php';
    });
  }

// ETO YUNG REALTIME
connectRealtime(message => {
  if (message.event === 'sale' || message.event === 'inventory') {
    // Products lang yung nire-reload kaya hindi nagagalaw yung cart at search
    reloadProducts().catch(() => {});
  }

  if (message.event === 'sale') {
    fetchRecords().then(renderRecords).catch(() => {});
  }
});
