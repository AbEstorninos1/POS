function confirmLogout() {
  showModal('Logout?', () => {
    location.href = '../auth/logout.php';
  });
}

let posRealtimeTimer = null;
let posRealtimeConnectedBefore = false;

function refreshPosData() {
  clearTimeout(posRealtimeTimer);

  posRealtimeTimer = setTimeout(() => {
    reloadProducts().catch(() => {});
    fetchRecords().then(renderRecords).catch(() => {});
  }, 300);
}

connectRealtime(message => {
  if (message.event === 'connected') {
    if (posRealtimeConnectedBefore) refreshPosData();

    posRealtimeConnectedBefore = true;
    return;
  }

  if (message.event === 'sale' || message.event === 'inventory') {
    refreshPosData();
  }
});
