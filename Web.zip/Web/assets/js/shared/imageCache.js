

// Dito ko kine-cache yung mga product image (Cache API) para hindi paulit-ulit nagda-download
const IMAGE_CACHE_NAME = 'product-images-v1';
const imageBlobUrls = new Map();

// Galing sa window.APP_ROOT yung root path, na sine-set ng bawat page kasi iba-iba yung lalim ng folder nila
function getAppRoot() {
  return window.APP_ROOT ?? '../';
}

function getPlaceholderSrc() {
  return getAppRoot() + 'assets/images/placeholder.svg';
}

function getImageUrl(path) {
  return new URL(getAppRoot() + path, document.baseURI).href;
}

async function cacheImage(path) {
  const url = getImageUrl(path);

  // Kapag walang Cache API sa browser, url na lang agad yung ibabalik
  if (!('caches' in window)) return url;

  
    const cache = await caches.open(IMAGE_CACHE_NAME);

    // Mag-fe-fetch lang kapag wala pa sa cache
    if (!(await cache.match(url))) {
      const response = await fetch(url);

      if (response.ok) {
        await cache.put(url, response);
      }
    }
  return url;
}

async function getImageSrc(path) {
  const url = getImageUrl(path);

  // Kung may blob URL na dati, yun na ulit yung gagamitin para hindi na mag-basa ulit sa cache
  if (imageBlobUrls.has(url)) return imageBlobUrls.get(url);

  await cacheImage(path);

  try {
    const cache = await caches.open(IMAGE_CACHE_NAME);
    const response = await cache.match(url);

    if (response) {
      // Ginagawang blob URL yung cached response para pwedeng ilagay sa src ng <img>
      const blobUrl = URL.createObjectURL(await response.blob());
      imageBlobUrls.set(url, blobUrl);
      return blobUrl;
    }
  } catch (error) {
    // Kapag pumalya yung cache, babalik na lang sa original na url sa baba
    
  }

  return url;
}


// Lahat ng <img> na may data-image, dito nilo-load yung totoong src (placeholder muna habang naghihintay)
function loadImages(container) {
  container.querySelectorAll('img[data-image]').forEach(async image => {
    image.src = await getImageSrc(image.dataset.image);
  });
}

async function preloadImages(paths, onProgress) {
  // Tinatanggal yung mga walang laman at duplicate na path
  const queue = [...new Set(paths.filter(Boolean))];
  const total = queue.length;
  const keep = new Set(queue.map(getImageUrl));
  let done = 0;

  if (onProgress) onProgress(0, total);

  async function worker() {
    while (queue.length > 0) {
      await cacheImage(queue.shift());
      done++;

      if (onProgress) onProgress(done, total);
    }
  }

  // 4 na worker na sabay-sabay nagda-download para mas mabilis kaysa isa-isa, basta ganun
  await Promise.all([worker(), worker(), worker(), worker()]);

  if ('caches' in window) {
    try {
      const cache = await caches.open(IMAGE_CACHE_NAME);

      // Nililinis yung cache: buburahin yung mga image na wala na sa current na listahan
      for (const request of await cache.keys()) {
        if (!keep.has(request.url)) await cache.delete(request);
      }
    } catch (error) {
      console.error('Could not clean the image cache:', error);
    }
  }
}
