<?php

session_start();

// Binubura yung login cookie para hindi na mag-auto login
setcookie('login', '', ['expires' => time() - 3600, 'path' => '/']);
session_destroy();

header('Location: ../index.php');
exit;
