<?php

session_start();
require_once __DIR__ . '/../config/database.php';

clearLoginCookie();
session_destroy();

header('Location: ../index.php');
exit;
