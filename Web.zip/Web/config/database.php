<?php
header('Content-Type: application/json');
ini_set('display_errors', '0');

set_exception_handler(function ($e) {
  http_response_code(500);
  echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
});

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = '127.0.0.1';
$user = 'root';
$password = 'root';
$database = 'POS';

try {
  $conn = new mysqli($host, $user, $password, $database);
  $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
  die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

if (!defined('REALTIME_URL')) define('REALTIME_URL', 'http://127.0.0.1:3000/notify');
if (!defined('REALTIME_KEY')) define('REALTIME_KEY', 'key');

function notifyRealtime($event, $data = []) {
  $payload = json_encode(['event' => $event, 'data' => $data]);

  if (function_exists('curl_init')) {
    $ch = curl_init(REALTIME_URL);

    curl_setopt_array($ch, [
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => $payload,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-Notify-Key: ' . REALTIME_KEY
      ],
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CONNECTTIMEOUT_MS => 400,
      CURLOPT_TIMEOUT_MS => 800
    ]);

    @curl_exec($ch);
    return;
  }

  $context = stream_context_create([
    'http' => [
      'method' => 'POST',
      'header' => "Content-Type: application/json\r\nX-Notify-Key: " . REALTIME_KEY . "\r\n",
      'content' => $payload,
      'timeout' => 0.8,
      'ignore_errors' => true
    ]
  ]);

  @file_get_contents(REALTIME_URL, false, $context);
}

const COOKIE_NAME = 'login';
const COOKIE_SECRET = 'MAG DROP NALANG';
const COOKIE_DAYS = 30;

function setLoginCookie($id, $passwordHash) {
  $expires = time() + COOKIE_DAYS * 86400;
  $signature = hash_hmac(
    'sha256',
    $id . '|' . $expires . '|' . $passwordHash,
    COOKIE_SECRET
  );

  sendLoginCookie($id . '.' . $expires . '.' . $signature, $expires);
}

function sendLoginCookie($value, $expires) {
  setcookie(COOKIE_NAME, $value, [
    'expires' => $expires,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax'
  ]);
}

function clearLoginCookie() {
  sendLoginCookie('', time() - 3600);
}

function restoreLogin($conn) {
  if (isset($_SESSION['user']) || empty($_COOKIE[COOKIE_NAME])) return;

  $parts = explode('.', $_COOKIE[COOKIE_NAME]);

  if (count($parts) !== 3) return;

  list($id, $expires, $signature) = $parts;

  $stmt = $conn->prepare(
    'SELECT id, username, password_hash, role, status FROM users WHERE id = ?'
  );

  $stmt->bind_param('i', $id);
  $stmt->execute();

  $user = $stmt->get_result()->fetch_assoc();

  if (!$user || $user['status'] !== 'Active' || (int) $expires < time()) {
    clearLoginCookie();
    return;
  }

  $expected = hash_hmac(
    'sha256',
    $id . '|' . $expires . '|' . $user['password_hash'],
    COOKIE_SECRET
  );

  if (!hash_equals($expected, $signature)) {
    clearLoginCookie();
    return;
  }

  session_regenerate_id(true);

  $_SESSION['user'] = [
    'id' => (int) $user['id'],
    'username' => $user['username'],
    'role' => $user['role']
  ];
}