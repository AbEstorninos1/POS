<?php

require_once __DIR__ . '/../../../config/database.php';


// Naka-una yung mga Pending para agad makita ng admin na kailangan pa nilang i-approve
$accounts = $conn->query("
  SELECT id, username, role, status, created_at
  FROM users
  ORDER BY status = 'Pending' DESC, id
")->fetch_all(MYSQLI_ASSOC);

echo json_encode($accounts);
