<div class="product-selection-container">

          <div class="product-selection-items">
            <div class="product-card-panel">

              <div class="product-category" id="productCategory">

                <button
                  class="category-arrow"
                  id="categoryPrev"
                  type="button"
  
                >&lt;</button>

                <div
                  class="product-category-items"
                  id="categoryItems"
                ></div>

                <button
                  class="category-arrow"
                  id="categoryNext"
                  type="button"

                >&gt;</button>

                <button
                  class="category-expand"
                  id="categoryExpand"
                  type="button"
                
                >⛶</button>

              </div>

              <div
                class="product-card-items"
                id="productCards"
              ></div>

              <div
                class="product-variants-panel"
                id="variantPanel"
                hidden
              >
                <header class="product-variants-header">
                  <button
                    class="back"
                    id="variantBack"
                    type="button"
                  >&lt;</button>

                  <h3 class="base-product" id="baseProduct">
                    Hammer
                  </h3>
                </header>

                <div
                  class="product-variants-items"
                  id="variantItems"
                ></div>
              </div>

            </div>
          </div>
        </div>
